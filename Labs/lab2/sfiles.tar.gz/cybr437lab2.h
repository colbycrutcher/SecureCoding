#ifndef LAB2_H
#define LAB2_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int * fillArray(int *size);
void printArray(int size, int * myArray);
int cleanUp(int ** myArray);



#endif
